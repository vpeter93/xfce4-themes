#/bin/bash
sudo rm -r /usr/share/themes/KirjaWood/gtk-2.0
sudo rm -r /usr/share/themes/KirjaWood/xfwm4
sudo rm -r /usr/share/themes/KirjaWood/xfce-notify-4.0
sudo rm -r /usr/share/themes/KirjaWood

